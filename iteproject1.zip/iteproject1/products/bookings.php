<!DOCTYPE html>
<html>
<head>
<meta name="author" content="Shivaani S (2020115082)"/>
	<title>Previous bookings</title>
	<link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,900&display=swap"
      rel="stylesheet"
    />
	 <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf"
      crossorigin="anonymous"
    />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/ext.css">
	<style>
	table,  td {
  border: 1px solid black;
  margin-left:auto;
  margin-right:auto;
}
th
{	
	border: 1px solid black;
	margin-left:auto;
	margin-right:auto;
	background-color:#0f2453;
	color:white;
}
	
	.col{
	color:white;
	}
	
</style>
	</head>
<body>
<header>
      <div>
        <i class="fas fa-globe-asia"></i>
        <p>Tourvelo</p>
      </div>
      <nav>
        <ul>
          <li><a href="../itept.html">Home</a></li>
          <li><a href="abt.html">About</a></li>
          <li><a href="tour.html">Packages</a></li>
          <li><a href="contact.html">Contact</a></li>
		  <li><a href="../index.php">Book Now</a></li>
<li><a href="../logout.php">Logout</a></li>
        </ul>
      </nav>

	  
    </header>
	<section class="box4">
<form  action="../index.php" method="get">
  <button>Exit</button>
</form>
	<div class="box4">
<?php
session_start();

	include("../connection.php");
	include("../functions.php");

	$user_data = check_login($con);
	$u=$user_data['id'];

echo "PREVIOUS BOOKINGS LIST";
	   $sql = "SELECT bookfinal.* FROM bookfinal INNER JOIN users1 ON bookfinal.uid = users1.id AND bookfinal.uid='$u'"; //select using foreign key only records in the acc
$result = mysqli_query($con,$sql);
echo "<table>";
echo "<tr>";
echo "<th>"."S.no"."</th>"."<th>"."Package"."</th>"."<th>"."Name"."</th>"."<th>"." Place from "."</th>"."<th>"."Total Cost"."</th>"."<th>"."Class of flight"."</th>"."<th>"."No of members"."</th>"."<th>"."Date"."</th>";
echo "</tr>";
$j=1;
if (mysqli_num_rows($result) > 0) {
  // output data of each row
  
  while($row = mysqli_fetch_array($result)) {
	  echo "<tr>";
	  echo "<td> ". $j."</td>";
	  if(($row["p"]=='shimla'))
	  { 
	  echo "<td>"." Shimla package"."</td>";}
  if($row["p"]=='delhi')
	  {echo "<td>"." Delhi package"."</td>";}
  if($row["p"]=='kerala')
	  {echo "<td>"." Kerala package"."</td>";}
  if($row["p"]=='goa')
	  {echo "<td>"." Goa package"."</td>";}
	 
  echo "<td> ". $row["name"]."</td>"."<td> ". $row["place"]."</td>"."<td>Rs.".$row['cost']."</td>"."<td>".$row['class']."</td>"."<td>".$row['no']."</td>"."<td>".$row['date']."</td>" ;
	  echo"</tr>";
	  $j++;
	  }
  
}


 else {
  echo "0 results";
	   mysqli_close($conn);
}
echo "</table>";
?>

</div>
</section>
<div class="sec">
	
	
	<footer>
  <h3>Also follow us on</h3>
  <a href="https://www.instagram.com/" class="fa fa-instagram"></a>
  <a href="https://www.twitter.com/" class="fa fa-twitter"></a>
  <p class="left">Main office at Chennai:Ram street No12,600035.<br>Phone:2433132<br>&#169; All rights reserved.<br>
  <a class='col' href="mailto:shivaanis32@gmail.com">Made by Shivaani</a>
  </p>
  </footer>
  </div>
</body>
</html>