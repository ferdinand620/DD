<?php
//search acc to input
if(isset($_GET['submit1']))
{
	$s=$_GET['myCountry'];
	if (strcasecmp($s,"Shimla package")==0)
	{
		echo "<script>location.href='products/web1.html'</script>";
	}
	else if (strcasecmp($s,"Delhi Package")==0)
	{
		echo "<script>location.href='products/delhi.html'</script>";
	}
	else if(strcasecmp($s,"goa Package")==0)
	{
		echo "<script>location.href='products/goa.html'</script>";
	}
	else if (strcasecmp($s,"kerala package")==0)
	{
		echo "<script>location.href='products/kerala.html'</script>";
	}
	else
	{
		echo "<h2>Search results not found!</h2><br><a href='index.html'>BACK</a>";
	}
}
?>