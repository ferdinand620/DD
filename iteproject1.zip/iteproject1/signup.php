<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
	<link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf"
      crossorigin="anonymous"
    />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/ext.css"/>
	
	<style>
	
	.text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;
	}

	#button{

		padding: 10px;
		width: 100px;
		color: black;
		background-color: #ffce14;
		border: none;
	}

	#box{

		background-color: #0f2453;
		margin: auto;
		width: 300px;
		padding: 20px;
		text-align:center;
	}
	.aaa{
	color:white;}
	.sign{
		font-size: 20px;
		margin: 10px;
		color: white;
	}
	
	</style>

</head>
<body>
<header>
	<div>
        <i class="fas fa-globe-asia"></i>
        <p>Tourvelo</p>
      </div>
	<nav>
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="products/abt.html">About</a></li>
          <li><a href="products/tour.html">Packages</a></li>
          <li><a href="products/contact.html">Contact Us</a></li>
        </ul>
      </nav>
	  
	  
    </header>

	

	

	<div id="box">
		
		<form method="post">
			<div class="sign">Signup</div>

			<input class="text" type="email" placeholder="Enter your email" name="user_name"><br><br>
			<input class="text" type="password" placeholder="Enter password" name="password"><br><br>

			<input id="button" type="submit" value="Signup"><br><br>

			<a class="aaa" href="login.php">Click to Login</a><br><br>
		</form>
	</div>
</body>
</html>
<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];
		

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{
			$check = "Select id  from users1 Where user_name ='$user_name'";
        $result = mysqli_query($con,$check);
			if (mysqli_num_rows($result)>=1)
			{ echo "<script>alert('Aldready registered pls login')</script>"; 
		echo "<h2 class='hh'>				Aldready Registered Login!</h2>";
			}
			else{
			//save to database
			$user_id = random_num(20);
			$query = "insert into users1 (user_id,user_name,password) values ('$user_id','$user_name','$password')";

			mysqli_query($con, $query);

			header("Location: login.php");
			die;
			}
		}else
		{
			echo "<h2 class='hh'>Please enter some valid information!</h2>";
		}
	}
?>


