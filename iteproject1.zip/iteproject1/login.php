

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,900&display=swap"
      rel="stylesheet"
    />
	 <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf"
      crossorigin="anonymous"
    />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/ext.css"/>
	<style>
	
	
	
	
	.text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;
	}

	#button{

		padding: 10px;
		width: 100px;
		color: black;
		background-color: #ffce14;
		border: none;
	}

	#box{

		background-color: #0f2453;
		margin: auto;
		width: 300px;
		padding: 20px;
		text-align:center;
	}
	.aaa{
	color:white;}
	.login{
		font-size: 20px;
		margin: 10px;
		color: white;
	}

	</style>
</head>
<body>

<header>
	<div>
        <i class="fas fa-globe-asia"></i>
        <p>Tourvelo</p>
      </div>
	<nav>
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="products/abt.html">About</a></li>
          <li><a href="products/tour.html">Packages</a></li>
          <li><a href="products/contact.html">Contact Us</a></li>
        </ul>
      </nav>
	  
	  
    </header>
	
	

	

	<div id="box">
		
		<form method="post">
			<div  class="login">Login</div>

			<input class="text" type="email" placeholder="Email" name="user_name"><br><br>
			<input class="text" type="password" placeholder="password" name="password"><br><br>
			<input type="checkbox" id="remember" value='1' name="remember">
			<label for="remember" class="aaa">Remember Me</label><br>

			<input id="button" type="submit" value="Login"><br><br>

			<a class="aaa" href="signup.php">Not registered? Click to Signup</a><br>
			<br>
		</form>
	</div>
	<?php 

session_start();

	include("connection.php");
	include("functions.php");
	

	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];
		if (isset($_POST["remember"]))
	{
		setcookie('user_name',$user_name,time()+60*60*7);
	}
		

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			//read from database
			$query = "select * from users1 where user_name = '$user_name' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					{
						
						$_SESSION['user_id'] = $user_data['user_id'];
						header("Location: index.php");
						die;
					}
				}
			}
			
			echo "<h2 class='hh'> Wrong username or password!</h2>";//display appropriate error messages
		}else
		{	echo "<script>alert('Wrong username or password')</script>";
			echo "<h2 class='hh'> Wrong username or password!</h2>";
		}
	}

?>
</body>
</html>