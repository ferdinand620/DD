<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Travel Website</title>
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf"
      crossorigin="anonymous"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,900&display=swap"
      rel="stylesheet"
    />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/ext.css">
    <style>
table, th, td {
  border: 1px solid black;
  margin-left:auto;
  margin-right:auto;
}
</style>
	
  </head>
  
  

    

<body>
<section class="box4">
<form  action="index.php" method="get">
  <button>Exit</button>
</form>
<?php
include("connection.php");
	include("functions.php");
	
	$host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbName = "login_sample_db";

	$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST['submit2'])) {
    
        $cid = -1;
        $bid = $_POST['bid'];
		$cid=$_POST['cid'];
		
        
		$curDate = date("Y-m-d");//taking current date
		
		$checkBID = "Select bookfinal.* from bookfinal  INNER JOIN  users1  ON    bookfinal.uid=users1.id Where bookfinal.id ='$bid' and bookfinal.uid= '$cid'";

        $result = mysqli_query($conn,$checkBID); 
		//echo mysql_num_rows($result);
		if (mysqli_num_rows($result)>=1)
		{
			if($r1 = mysqli_fetch_assoc($result))
			{
				echo "ID : ".$r1["id"]." - Date Of Departure : ".$r1["date"]. "<br>" ;
				$res= dateCompare($r1["date"], $curDate);
				
			

			if($res==1)
			{
				$sql="DELETE FROM bookfinal WHERE id='$bid'"; //deleting if the condn is true
				if ($conn->query($sql) === TRUE)
				{
			
			echo "<h2>Booking cancelled successfully</h2><br>";
				}
			}				
		    else 
		    {
			  echo "<h2>Oops! cant be cancelled!Date Passed!</h2><br>*Last date to cancel any booking is a day before the date of departure! " ;
		    }
			}
		}
			
		
		else
		{
			echo "<h2>Your Booking ID ".$bid." for Cancellation does not exist</h2> <br>";//confirmation messages
        
		}
}

function dateCompare($Depart, $Current)
{
$date1 = date("Y-m-d",strtotime($Depart));
$date2 = $Current;

$datetime1 = date_create($date2);
$datetime2 = date_create($date1);
  
// calculates the difference between DateTime objects
$interval = date_diff($datetime1, $datetime2);
  
// printing result in days format
$days1= $interval->format('%R%a');
if ($days1 >= 1)
    return 1 ;
else
	return 0;
}

$conn->close();
?>

</section>
</body>
</html>
		
