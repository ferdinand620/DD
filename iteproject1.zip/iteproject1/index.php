<?php 
session_start();

	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);


?>

<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Travel Website</title>
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf"
      crossorigin="anonymous"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,900&display=swap"
      rel="stylesheet"
    />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/ext.css" />
	<style>
	.logo{
		font-size:40px;
		color:#ffce14;
	}
	.buton{
		color:black;
	background-color:#ffce14;}
	
	</style>
	
  </head>
  
  

    

<body>




<header>
      <div>
        <i class="fas fa-globe-asia"></i>
        <p>Tourvelo</p>
      </div>
      <nav>
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="products/abt.html">About</a></li>
          <li><a href="products/tour.html">Packages</a></li>
          <li><a href="products/contact.html">Contact Us</a></li>
<li><a href="logout.php">Logout</a></li>
        </ul>
      </nav>

	  
    </header>
	<script src="js/jss.js"></script>

	

	<br>
	
	
	
	
	<div class="box3">
	
	
	 
	
	<p class="abcd"><i class="glyphicon glyphicon-user" 
	></i>  <a  href="cancel.php"></a>   
	 <br> Welcome Back, <?php echo $user_data['user_name']." <br>user id:".$user_data['id']; ?></p>



<form  action="cancel.php" method="get">
  
  <button>CANCEL BOOKING: Pls read the terms and conditions below and then click here (Last date of cancellation will be a day before your departure)</button>
</form>
<div class="hh">
<?php
$d=$user_data['id'];
	$sql = "SELECT * FROM bookfinal WHERE bookfinal.uid='$d'";

$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result) > 0) {
	echo "<form  action='products/bookings.php' method='get'>
  
  <button class='buton'>View My Previous Bookings</button>
</form>";
echo "<h2 class='hh'>Book Now</h2>";
}
else
{ echo "<h2 class='hh'>Book Now</h2>";
}

?>


</div>


	<form name="myforms" action="su.php" method="post" onsubmit="return validateForm()">
	
	
	<br><label class="label" for="fname"> Name : </label>
  <input type="text" id="fname" name="fname" value=<?php $d=$user_data['id'];
	$sql = "SELECT * FROM bookfinal WHERE bookfinal.uid='$d'";

$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_array($result)){
	
echo  $row["name"];
break;
	  }
}else {echo " ";} ?> ><br>
  <label class="label" for="lname">Mail Id:</label>
  <input type="text" id="lname" name="lname" ><br>
  
  <input type="hidden" id="uid" name="uid"  value=<?php echo $user_data["id"];?>> <br>
  <label class="label" for="ud">Phone no:</label>
  <input type="number" id="ud" name="ud" ><br><br>
  <p class="label">Please select one Package at a time:</p><br><br>
  <input type="radio" id="html" name="pk" value="shimla">
<label  for="html">Shimla Package</label><br>
<input type="radio" id="css" name="pk" value="delhi">
<label for="css">Delhi Package</label><br>
<input type="radio" id="javascript" name="pk" value="kerala">
<label for="javascript">Kerala Package</label><br>
<input type="radio" id="g" name="pk" value="goa">
<label for="g">Goa Package</label><br><br>
<label class="label" for="birthday">Date of departure:</label>
<input type="date" id="birthday" placeholder="yyyy-mm-dd" name="birthday" ><br><br>
<label class="label"  for="no">No of members (Max 9):</label>
  <input type="number" min='1' max='9' id="no" name="no" value='1' required><br><br>

<label class="label" for="place">From:</label>
 <select id="place" name="place">
    <option value="Chennai">Chennai</option>
    <option value="Banglore">Banglore</option>
    <option value="Coimbatore">Coimbatore</option>
    <option value="Salem">Salem</option>
	<option value="Cochin">Cochin</option>
    <option value="Madurai">Madurai</option>
  </select><br>
<p class="label">Please select class of flight</p><br><br>
  <input type="radio" id="first1" name="c" value="first">
<label  for="first1">First Class (Rs. 70,000)(f)</label><br>
<input type="radio" id="first" name="c" value="economy">
<label for="first">Economy Class (Rs. 20,000)(e)</label><br>

  <a href='https://drive.google.com/file/d/1Ez4Wf6tRiGVQhNJRkC6FeJ-uwkhM6K_7/view?usp=drivesdk'> *TERMS AND CONDITIONS</a><br>
  <input type="submit" name="submit" value="Book">
 
  
</form>





</div>
<div class="sec">
	
	
	<footer>
  <h3>Also follow us on</h3>
  <a href="https://www.instagram.com/" class="fa fa-instagram"></a>
  <a href="https://www.twitter.com/" class="fa fa-twitter"></a>
  <p class="left">Main office at Chennai:Ram street No12,600035.<br>Phone:2433132<br>&#169; All rights reserved.<br>
  </p>
  </footer>
  </div>

	
</body>
</html>