<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="UTF-8" />
	<meta name="author" content="Shivaani S (2020115082)"/>
    <title>Book</title>
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf"
      crossorigin="anonymous"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,900&display=swap"
      rel="stylesheet"
    />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/ext.css">
    <style>
table, th, td {
  border: 1px solid black;
  margin-left:auto;
  margin-right:auto;
}
</style>
	
  </head>
  
  

    

<body>

<section class="box4">
<form  action="index.php" method="get">
  <button>Exit</button>
</form>


<?php



$host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbName = "login_sample_db";
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);//making db connection

if(!$conn)
{
	die("connection failed");
}



if (isset($_POST['submit'])) {
    //on submitting getting details via POST and calculation of total cost
        
        $name = $_POST['fname'];
        $email = $_POST['lname'];
		
        
		$u=$_POST['uid'];
		$uid=$u;
        $phone = $_POST['ud'];
        $p = $_POST['pk'];
        $date = $_POST['birthday'];
		$place=$_POST['place'];
		$cost=0;
		$no=$_POST['no'];
		$class=$_POST['c'];
		$flightcost=0;
		if (($no>2) and ($no<=5))
		{	echo "YOU HAVE A DISCOUNT OF 40% on flight and package";
			if ($p=="shimla")
			{
			echo "<br>NAME: SHIMMU AIRWAYS<br>";
			
			$cost=(90000-90000*0.4)*$no;
			}
			else if($p=="delhi")
			{
				echo "<br>NAME: FLY AIRWAYS<br>";
			$cost=(90000-90000*0.4)*$no;
			}
			else if($p=="kerala")
			{
				echo "<br>NAME: JASS AIRWAYS<br>";
			$cost=(30000-30000*0.4)*$no;
			}
			else if($p=="goa")
			{
				echo "<br>NAME: EMIRATES<br>";
			$cost=(50000-50000*0.4)*$no;
			}
			if ($class=="first")
		{	$cost=$cost+(70000-70000*0.4)*$no*2;
	echo "<br>Total flight cost: Rs.".(70000-70000*0.4)*$no*2;
			//$flightcost=(70000-70000*0.5)*$no*2;
		}
		else
		{	$cost=$cost+(20000-20000*0.4)*$no*2;
	echo "<br>Total flight cost: Rs.".(20000-20000*0.4)*$no*2;
			
		}
		}
		else if (($no>5) and ($no<=9))
		{	echo "YOU HAVE A DISCOUNT OF 50% on flight and package";
			if ($p=="shimla")
			{
			echo "<br>NAME: SHIMMU AIRWAYS<br>";
			
			$cost=(90000-90000*0.5)*$no;
			}
			else if($p=="delhi")
			{
				echo "<br>NAME: FLY AIRWAYS<br>";
			$cost=(90000-90000*0.5)*$no;
			}
			else if($p=="kerala")
			{
				echo "<br>NAME: JASS AIRWAYS<br>";
			$cost=(30000-30000*0.5)*$no;
			}
			else if($p=="goa")
			{
				echo "<br>NAME: EMIRATES<br>";
			$cost=(50000-50000*0.5)*$no;
			}
			if ($class=="first")
		{	$cost=$cost+(70000-70000*0.5)*$no*2;
			echo "<br>Total flight cost Rs.".(70000-70000*0.5)*$no*2;
			
		}
		else
		{	$cost=$cost+(20000-20000*0.5)*$no*2;
	echo "<br>Total flight cost Rs.".(20000-20000*0.5)*$no*2;
	
	
	
		}
	}
		
		
		else if($no<=2)
		{
			if ($p=="shimla")
			{
				echo "<br>NAME: SHIMMU AIRWAYS<br>";
			$cost=(90000)*$no;
			}
			else if($p=="delhi")
			{
				echo "<br>NAME: FLY AIRWAYS<br>";
			$cost=(90000)*$no;
			}
			else if($p=="kerala")
			{
				echo "<br>NAME: JASS AIRWAYS<br>";
			$cost=(30000)*$no;
				}
				else if($p=="goa")
			{
				echo "<br>NAME: EMIRATES<br>";
			$cost=(50000)*$no;
				}
		
		if ($class=="first")
		{	$cost=$cost+(70000)*$no*2;
			echo "<br>Total flight cost Rs.".(70000)*$no*2;
		}
		else
		{	$cost=$cost+(20000)*$no*2;
			echo "<br>Total flight cost Rs. ".(20000)*$no*2;
		}
		}
		
//inserting the values into table
       $sql_query="INSERT INTO bookfinal (id,name,email,uid,phone,p,date,place,cost,no,class) VALUES (NULL,'$name','$email','$uid','$phone','$p','$date','$place','$cost','$no','$class')";
	 
	   if (mysqli_query($conn,$sql_query))
	   {
		   
		   echo "<br><h2>Booking successful!</h2><br>";
		   
	
		   echo "Package: ".$p."<br>"."Date: ".$date."<br>"."Name: ".$name."<br>Phone: ".$phone."<br>Email: ".$email."<br>"."Place: ".$place."<br>"."No. of members: ".$no."<br>"."Total Cost Rs.".$cost."<br>";
		   
		   
		   
		   
	   }
	   else{
		   echo "Invalid User id";
	   }

echo "<br>PREVIOUS BOOKINGS LIST";//displaying prev bookings
	   $sql = "SELECT * FROM bookfinal INNER JOIN users1 ON bookfinal.uid = users1.id AND bookfinal.uid='$u'";
$result = mysqli_query($conn,$sql);
echo "<table>";
echo "<tr>";
echo "<th>"."Package"."</th>"."<th>"."Name"."</th>"."<th>"."Place from"."</th>"."<th>"."Username"."</th>"."<th>"."Total Cost"."</th>"."<th>"."Class of flight"."</th>"."<th>"."No of members"."</th>";
echo "</tr>";
if (mysqli_num_rows($result) > 0) {
  // output data of each row
  
  while($row = mysqli_fetch_array($result)) {
	  echo "<tr>";
	  if(($row["p"]=='shimla'))
	  { 
	  echo "<td>"." Shimla package"."</td>";}
  if($row["p"]=='delhi')
	  {echo "<td>"." Delhi package"."</td>";}
  if($row["p"]=='kerala')
	  {echo "<td>"." Kerala package"."</td>";}
  if($row["p"]=='goa')
	  {echo "<td>"." Goa package"."</td>";}
	 
  echo "<td> "." Name: " . $row["name"]."</td>"."<td> "." Place: " . $row["place"]."</td>"."<td>".$row['user_name']."</td>"."<td>Rs.".$row['cost']."</td>"."<td>".$row['class']."</td>"."<td>".$row['no']."</td>" ;
	  echo"</tr>";}
  
}


 else {
  echo "0 results";
	   mysqli_close($conn);
}
echo "</table>";
}

 



?>
</section>

</body>
</html>
   