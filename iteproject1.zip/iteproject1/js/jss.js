function validateForm() {//checking if name is empty
  var x = document.forms["myforms"]["fname"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
var m=document.forms["myforms"]["lname"].value;
if (m ==""){
	alert("Pls enter mailid");
	return false;
  
}
 var e = document.forms["myforms"]["uid"].value;
  if (e == "") {
    alert("User id must be filled out");
    return false;
  }

var getSelectedValue = document.querySelector(   
                'input[name="pk"]:checked');   
                
            if(getSelectedValue == null) {   
                alert("please select package");
				return false;
			}
			var text=document.forms["myforms"]["ud"].value;
			 var regx = /^\d{10}$/ ;
  if(!(regx.test(text)))
  {
    alert("invalid Phone no");
	return false;
  }
   
var email = document.forms["myforms"]["lname"].value;  
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email)) {
    alert('**Please provide a valid email address');
    email.focus;
    return false;
 } 
 
  var d = document.forms["myforms"]["birthday"].value;
   var regEx = /^\d{4}-\d{2}-\d{2}$/;
 if( d.match(regEx) == null)
 {alert("eneter date in right format");
 return false;}
var d1=new Date(); //yyyy-mm-dd  
var d2=new Date(d); //yyyy-mm-dd  
if(d1>d2)  
{  
alert("Enter a Valid future date");  
return false;
} 
var p=document.forms["myforms"]["place"].value;
if (p == "")
{
	alert("Enter the from place");
return false;
}
var getSelectedValue1 = document.querySelector(   
                'input[name="c"]:checked');   
                
            if(getSelectedValue1 == null) {   
                alert("please select the flight class");
				return false;
			}

 
else{
alert("Done submitted")	
}
}
function validateForm1()

{	var b=document.forms["myforms2"]["bid"].value;
if (b ==""){
	alert("Pls enter the booking id");
	return false;
  
}

	var d = document.forms["myforms2"]["date"].value;
   var regEx = /^\d{4}-\d{2}-\d{2}$/;
 if( d.match(regEx) == null)
 {alert("eneter date in right format");
 return false;}
var d1=new Date(); //yyyy-mm-dd  
var d2=new Date(d); //yyyy-mm-dd  
if(d1>d2)  
{  
alert("Sorry cant cancel. cancelling date passed");  
return false;
}}
function validateForm2() {//checking if name is empty
  var x = document.forms["myforms3"]["fname"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  } 
//checking if name is empty
  var e = document.forms["myforms3"]["email"].value;
  if (e == "") {
    alert("email must be filled out");
    return false;
  }  
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var email = document.forms["myforms3"]["email"].value;  
    if (!filter.test(email)) {
    alert('**Please provide a valid email address');
    email.focus;
    return false;
 } 
}