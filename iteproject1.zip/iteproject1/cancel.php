  
  <?php 
session_start();

	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head>
	<title>Cancel</title>
	<link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,900&display=swap"
      rel="stylesheet"
    />
	 <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
      integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf"
      crossorigin="anonymous"
    />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Shivaani S (2020115082)"/>
	<link rel="stylesheet" href="css/ext.css">
	<style>
	table,  td {
  border: 1px solid black;
  margin-left:auto;
  margin-right:auto;
}
th
{	
	border: 1px solid black;
	margin-left:auto;
	margin-right:auto;
	background-color:#0f2453;
	color:white;
}

	.col{
	color:white;
	}
	
	
</style>
	</head>
<body>
<header>
      <div>
        <i class="fas fa-globe-asia"></i>
        <p>Tourvelo</p>
      </div>
      <nav>
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="products/abt.html">About</a></li>
          <li><a href="products/tour.html">Packages</a></li>
          <li><a href="products/contact.html">Contact</a></li>
		  <li><a href="index.php">Book Now</a></li>
<li><a href="logout.php">Logout</a></li>
        </ul>
      </nav>

	  
    </header>
<script src="js/jss.js"></script>
<div class="box4">
<p class="abcd">Cancellation</p>

<form  action="delete.php" method="post" name="myforms2" onsubmit="return validateForm1()">
	
	
  <input type="hidden"  id="cid" name="cid" value=<?php echo $user_data["id"];?>><br>
	<label class="label" for="bid"> Booking Id :</label>
  <input type="text" id="bid" name="bid" ><br>
  
	
  
  <input  type="submit" class="hh" name="submit2" value="Confirm and cancel">
  </form>
  
  

 
 
 <?php
 

	$host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbName = "login_sample_db";
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
$d=$user_data['id'];

	$sql = "SELECT * FROM bookfinal WHERE bookfinal.uid='$d'"; //selecting records only from this account
$result = mysqli_query($conn,$sql);
$j=1;
if (mysqli_num_rows($result) > 0) {
  // output data of each row
  echo "<h3 class='hh'><br>   PREVIOUS BOOKINGS LIST</h3>";
  echo "<table>";
 
echo "<tr>";
echo "<th>"."S.no"."</th>"."<th>"."Package"."</th>"."<th>"."Name"."</th>"."<th>"."Place from"."</th>"."<th>"."Booking Id"."</th>"."<th>"."Date of departure"."</th>"."<th>"."Class of flight"."</th>"."<th>"."No of members"."</th>"."<th>"."Total Cost"."</th>";
echo "</tr>";

  while($row = mysqli_fetch_array($result)) {
	  echo "<tr>";
	  echo "<td> ". $j."</td>";
	  if($row["p"]=='shimla')
	  {echo "<td>"."Shimla (Rs.90,000) "."</td>";}
  if($row["p"]=='delhi')
	  {echo "<td>"." Delhi (Rs.90,000)"."</td>";}
   if($row["p"]=='kerala')
	  {echo "<td>"." Kerala (Rs.30,000)"."</td>";}
  if($row["p"]=='goa')
	  {echo "<td>"." Goa (Rs.50,000)"."</td>";}
	 
  
	 
  echo "<td> ". $row["name"]."</td>"."<td> " . $row["place"]."</td>"."<td>".$row['id']."</td>"."<td>".$row['date']."</td>"."<td>".$row['class']."</td>"."<td>".$row['no']."</td>"."<td>".$row['cost']."</td>";//printing previous bookings
	  echo"</tr>";
	  $j++;
	  }
  
} echo "</table>";

?>
</div>
<div class="sec">
	
	
	<footer>
  <h3>Also follow us on</h3>
  <a href="https://www.instagram.com/" class="fa fa-instagram"></a>
  <a href="https://www.twitter.com/" class="fa fa-twitter"></a>
  <p class="left">Main office at Chennai:Ram street No12,600035.<br>Phone:2433132<br>&#169; All rights reserved.<br>
  <a class='col' href="mailto:shivaanis32@gmail.com">Made by Shivaani</a>
  </p>
  </footer>
  </div>

</body>
</html>

